/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minijuegos.dto;

/**
 *
 * @author Alumno
 */
public class Usuario {
    
    //Atributos
    private String nombre;
    private int puntuacion;
    
    //Constructor
    public Usuario(String nombre) {
        this.nombre = nombre;
        this.puntuacion = 0;
    }
    
    //Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }
       
   //Metodo para aumentar la puntuación
    public void sumarPuntos(int puntos) {
        this.puntuacion += puntos;
    }
    
}
